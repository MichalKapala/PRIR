import java.util.List;

public class ConcreteDeltaReceiver implements DeltaReceiver {
    /**
     * Do tej metody należy dostarczyć listę wykrytych różnic pomiędzy danymi
     * z różnych zestawów.
     *
     * @param deltas lista różnic
     */

    private int deltaCounter = 0;
    public void accept(List<Delta> deltas) {
        if(!deltas.isEmpty())
        {
//            var firstDelta = deltas.get(0);
//            System.out.println(firstDelta.getDataID());
        }

    }
}
